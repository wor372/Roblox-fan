# Sharp Bot Dashboard

Discord OAuth2 login + multi-category web dashboard for Render.

## Deploy to Render
1. Upload this folder to a GitHub repository.
2. In Render choose **New + → Web Service** and connect the repository.
3. Build command: `npm install`; Start command: `npm start`.
4. Add environment variables:
   - `DISCORD_CLIENT_ID`: Application ID from Discord Developer Portal
   - `DISCORD_CLIENT_SECRET`: OAuth2 Client Secret (keep private)
   - `DISCORD_REDIRECT_URI`: `https://YOUR-SERVICE.onrender.com/auth/callback`
   - `SESSION_SECRET`: long random secret
5. In Discord Developer Portal → OAuth2 → Redirects, add the exact same callback URL.
6. Open the Render URL and use **Přihlásit se přes Discord**.

## Categories
Overview, General, Tickets, Roles & Permissions, Moderation, Anti-spam & Protection, Verification, Giveaways, Logs, Welcome.

## Important limitations
- This web service stores settings in `data/guild-config.json`. Render's free service filesystem may be ephemeral, so data can reset on redeploy/restart. Use a persistent disk or external database for durable storage.
- Settings are **not yet synced to the running Discord bot**. To make them live, the bot must call this service's API or share a database, with authentication between the bot and dashboard. Do not expose a bot token in browser code.
- OAuth checks that the logged-in user can Manage Server or has Administrator. The Discord bot must separately enforce its own Bot Manager role for every sensitive command/action.
- Set `ALLOWED_USER_IDS` optionally to restrict dashboard access to a comma-separated allowlist of Discord user IDs.
